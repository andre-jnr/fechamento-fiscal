# conector-erp — fechamento conectado ao ERP

Servidor local que busca as entradas de nota direto do banco do sistema (SQL Server),
pela VPN da empresa, e alimenta a página de conciliação sem precisar exportar/subir o
XLSX manualmente.

**Este pacote não vem com nenhuma credencial.** Você precisa preencher o `.env` e o
`config/unidades.js` com os dados do seu próprio ambiente antes de usar — nada aqui
sai da sua máquina além da consulta que você mesmo configurar até o seu SQL Server.

## Passo a passo

1. Instale o [Node.js](https://nodejs.org/) (versão LTS) se ainda não tiver.
2. Extraia este zip inteiro em uma pasta no computador (mantenha a estrutura de
   pastas — `conector-erp/` precisa ficar dentro da pasta com `conciliacao.html`).
3. Dentro de `conector-erp/`, copie `.env.example` para `.env` e preencha:
   - `DB_USER` / `DB_PASSWORD` — usuário e senha do SQL Server.
   - `DB_PORT` — porta do SQL Server (normalmente 1433).
4. Abra `conector-erp/config/unidades.js` e, para cada unidade, troque
   `SERVIDOR_AQUI` pelo endereço/host do servidor e `BANCO_AQUI` pelo nome do banco —
   apague as linhas de exemplo que não usar e adicione quantas precisar.
5. Dentro de `conector-erp/`, dê duplo clique em `iniciar.bat` — ele instala as
   dependências (só na primeira vez), sobe o servidor e abre
   `http://localhost:3000/conciliacao.html` no navegador. É necessário estar
   conectado na VPN da empresa para alcançar o banco.

## O que ele faz

- Serve a página de conciliação (`conciliacao.html` e as demais páginas) localmente,
  na mesma origem do servidor — o card "SISTEMA" passa a mostrar a opção de buscar
  direto do banco, além do upload manual (que continua funcionando normalmente).
- Expõe `GET /api/sistema?unidade=...&de=...&ate=...`, que roda uma consulta em
  `Entrada_Produto` e devolve os lançamentos no mesmo formato do export manual do
  Moura (Entrada, NF, Fornecedor, Valores, Chave de Acesso, etc.).

## Aviso

`query.js` tem dois pontos marcados com `TODO` (nome do fornecedor e o valor total da
nota) que dependem da estrutura exata do seu banco — ajuste-os se o resultado vier
incompleto.
