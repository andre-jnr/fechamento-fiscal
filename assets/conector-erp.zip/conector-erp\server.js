require('dotenv').config({ path: require('path').join(__dirname, '.env') })

const path = require('path')
const express = require('express')
const { getPool, getUnidade, UNIDADES } = require('./db')
const { buscarEntradaProduto, linhasParaRawMatrix } = require('./query')

const app = express()
const PORT = Number(process.env.PORT) || 3000
const REPO_ROOT = path.join(__dirname, '..')

// Serve o site estático (raiz do repo) na mesma origem do servidor local, assim o
// fetch('/api/...') feito pela página funciona sem esbarrar em mixed content
// (HTTPS do GitHub Pages não pode chamar http://localhost).
app.use(express.static(REPO_ROOT))

app.get('/api/health', (req, res) => {
  res.json({ ok: true })
})

app.get('/api/unidades', (req, res) => {
  res.json(UNIDADES.map((u) => ({ chave: u.chave, nome: u.nome })))
})

app.get('/api/sistema', async (req, res) => {
  const { unidade, de, ate } = req.query
  if (!unidade || !de || !ate) {
    return res.status(400).json({ erro: 'Parâmetros obrigatórios: unidade, de, ate (YYYY-MM-DD).' })
  }

  const config = getUnidade(unidade)
  if (!config) {
    return res.status(400).json({ erro: `Unidade desconhecida: ${unidade}` })
  }

  try {
    const pool = await getPool(unidade)
    const linhas = await buscarEntradaProduto(pool, { de, ate })
    const rawMatrix = linhasParaRawMatrix(linhas, config.nome)
    res.json({ rawMatrix })
  } catch (err) {
    console.error(`[conector-erp] erro consultando ${unidade}:`, err.message)
    res.status(500).json({ erro: `Falha ao consultar o banco da unidade "${config.nome}": ${err.message}` })
  }
})

app.listen(PORT, () => {
  console.log(`conector-erp rodando em http://localhost:${PORT}`)
  console.log(`Abra http://localhost:${PORT}/conciliacao.html`)
})
