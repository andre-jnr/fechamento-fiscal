// Preencha o servidor e o banco de cada unidade antes de rodar o conector.
// Copie/apague linhas conforme o numero de unidades que voce tem.
// "chave" e o identificador usado na URL (sem espaco/acento); "nome" e o que
// aparece no seletor da pagina.
module.exports = [
  { chave: 'unidade-1', nome: 'Unidade 1', server: 'SERVIDOR_AQUI', database: 'BANCO_AQUI' },
  { chave: 'unidade-2', nome: 'Unidade 2', server: 'SERVIDOR_AQUI', database: 'BANCO_AQUI' },
]
