@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================
echo   Fechamento Fiscal - Conector ERP local
echo ============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao encontrado no PATH.
  echo Baixe e instale em https://nodejs.org/ e rode este arquivo de novo.
  echo.
  pause
  exit /b 1
)

if not exist ".env" (
  echo [SETUP] Nenhum .env encontrado - copiando .env.example para .env...
  copy /y ".env.example" ".env" >nul
  echo.
  echo [ATENCAO] Abra o arquivo .env e preencha DB_USER e DB_PASSWORD com as
  echo credenciais do banco antes de continuar.
  echo Abra tambem config\unidades.js e preencha o servidor e o banco de
  echo cada unidade ^(troque os valores "SERVIDOR_AQUI" / "BANCO_AQUI"^).
  echo.
  pause
  exit /b 1
)

findstr /c:"SERVIDOR_AQUI" "config\unidades.js" >nul 2>nul
if not errorlevel 1 (
  echo [ATENCAO] config\unidades.js ainda tem os valores de exemplo
  echo ^("SERVIDOR_AQUI" / "BANCO_AQUI"^). Edite o arquivo com o servidor e o
  echo banco reais de cada unidade antes de continuar.
  echo.
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo [SETUP] Instalando dependencias pela primeira vez ^(pode levar 1-2 min^)...
  call npm install
  if errorlevel 1 (
    echo [ERRO] Falha ao instalar as dependencias.
    pause
    exit /b 1
  )
  echo.
)

echo Subindo o servidor local em http://localhost:3000 ...
start "Fechamento Fiscal - conector-erp" cmd /k "npm start"

timeout /t 3 /nobreak >nul
start "" "http://localhost:3000/conciliacao.html"

endlocal
