/**
 * Leitura e validação dos arquivos importados (CSV da SEFAZ e XLSX/XLS do
 * sistema interno). Usa SheetJS (window.XLSX) para os dois formatos.
 */
;(function (global) {
  'use strict'

  const Engine = global.ConciliacaoEngine

  class ConciliacaoImportError extends Error {}

  const MSG_ARQUIVO_INVALIDO =
    'Arquivo inválido. Verifique se o arquivo corresponde ao layout esperado.'
  const MSG_ARQUIVO_VAZIO = 'O arquivo não possui registros para conciliação.'
  const MSG_FORMATO_INVALIDO = 'Não foi possível interpretar os dados deste arquivo.'
  const msgColunaAusente = (nome) =>
    `Não foi possível importar o arquivo porque a coluna "${nome}" não foi encontrada.`

  function normalizeHeader(s) {
    return String(s == null ? '' : s)
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .toUpperCase()
      .replace(/\s+/g, ' ')
      .trim()
  }

  function findColumnIndex(headerRow, candidates, fromIndex) {
    const normalized = headerRow.map(normalizeHeader)
    const wanted = candidates.map(normalizeHeader)
    for (let i = fromIndex || 0; i < normalized.length; i++) {
      if (wanted.includes(normalized[i])) return i
    }
    return -1
  }

  function readFileAsArrayBuffer(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(reader.result)
      reader.onerror = () => reject(reader.error)
      reader.readAsArrayBuffer(file)
    })
  }

  function bytesStartWith(bytes, signature) {
    if (bytes.length < signature.length) return false
    for (let i = 0; i < signature.length; i++) {
      if (bytes[i] !== signature[i]) return false
    }
    return true
  }

  function isZipSignature(bytes) {
    return bytesStartWith(bytes, [0x50, 0x4b, 0x03, 0x04])
  }

  function isOleSignature(bytes) {
    return bytesStartWith(bytes, [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1])
  }

  // Algumas exportações de Excel gravam um "!ref" (dimensão) desatualizado,
  // menor do que os dados reais da planilha — recalcula a partir das
  // células realmente presentes para não truncar linhas/colunas.
  function fixSheetRange(sheet) {
    let minR = Infinity
    let minC = Infinity
    let maxR = -Infinity
    let maxC = -Infinity
    for (const key of Object.keys(sheet)) {
      if (key[0] === '!') continue
      const addr = global.XLSX.utils.decode_cell(key)
      if (addr.r < minR) minR = addr.r
      if (addr.c < minC) minC = addr.c
      if (addr.r > maxR) maxR = addr.r
      if (addr.c > maxC) maxC = addr.c
    }
    if (maxR === -Infinity) return
    sheet['!ref'] = global.XLSX.utils.encode_range({
      s: { r: minR, c: minC },
      e: { r: maxR, c: maxC },
    })
  }

  // -----------------------------------------------------------------------
  // SEFAZ (CSV)
  // -----------------------------------------------------------------------

  const SEFAZ_REQUIRED_FIELDS = [
    { key: 'uf', names: ['UF'], label: 'UF' },
    { key: 'nf', names: ['NUMERO', 'NF', 'NUMERO NF'], label: 'NF (NUMERO)' },
    { key: 'serie', names: ['SERIE'], label: 'Série' },
    { key: 'emissao', names: ['EMISSAO', 'DATA EMISSAO'], label: 'Emissão' },
    { key: 'cnpjEmissor', names: ['CNPJ EMISSOR'], label: 'CNPJ Emissor' },
    {
      key: 'cnpjDestinatario',
      names: ['CNPJ-CPF DESTINATARIO', 'CNPJ DESTINATARIO', 'CPF-CNPJ DESTINATARIO'],
      label: 'CNPJ/CPF Destinatário',
    },
    { key: 'cfop', names: ['CFOP'], label: 'CFOP' },
    { key: 'situacao', names: ['SITUACAO'], label: 'Situação' },
    { key: 'tipo', names: ['TIPO'], label: 'Tipo' },
    { key: 'valor', names: ['VALOR'], label: 'Valor' },
    { key: 'rejeitada', names: ['REJEITADA'], label: 'Rejeitada' },
  ]

  async function parseSefazCsv(file) {
    let buffer
    try {
      buffer = await readFileAsArrayBuffer(file)
    } catch (e) {
      throw new ConciliacaoImportError(MSG_ARQUIVO_INVALIDO)
    }

    const bytes = new Uint8Array(buffer.slice(0, 8))
    if (isZipSignature(bytes) || isOleSignature(bytes)) {
      // Excel disfarçado de CSV
      throw new ConciliacaoImportError(MSG_ARQUIVO_INVALIDO)
    }

    let text
    try {
      text = new TextDecoder('windows-1252').decode(buffer)
    } catch (e) {
      text = new TextDecoder('utf-8').decode(buffer)
    }

    // remove BOM e a linha de pragma "sep=;" usada por exportações do Excel
    text = text.replace(/^﻿/, '')
    text = text.replace(/^sep=.\r?\n/i, '')

    let workbook
    try {
      workbook = global.XLSX.read(text, { type: 'string', FS: ';', raw: true })
    } catch (e) {
      throw new ConciliacaoImportError(MSG_FORMATO_INVALIDO)
    }

    const sheetName = workbook.SheetNames[0]
    if (!sheetName) throw new ConciliacaoImportError(MSG_FORMATO_INVALIDO)
    const sheet = workbook.Sheets[sheetName]
    fixSheetRange(sheet)

    let matrix
    try {
      matrix = global.XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: '' })
    } catch (e) {
      throw new ConciliacaoImportError(MSG_FORMATO_INVALIDO)
    }

    const result = sefazRowsFromMatrix(matrix)
    result.fileName = file.name
    return result
  }

  // Reconstrói as linhas normalizadas a partir da matriz bruta (linha 0 =
  // cabeçalho). Usado tanto pelo parser de arquivo quanto pela importação de
  // um arquivo de conciliação (.json), garantindo resultado idêntico.
  function sefazRowsFromMatrix(rawMatrix) {
    const matrix = (rawMatrix || []).filter(
      (row) => Array.isArray(row) && row.some((cell) => String(cell).trim() !== '')
    )
    if (matrix.length === 0) throw new ConciliacaoImportError(MSG_ARQUIVO_VAZIO)

    const headerRow = matrix[0]
    const dataRows = matrix.slice(1)
    if (dataRows.length === 0) throw new ConciliacaoImportError(MSG_ARQUIVO_VAZIO)

    const colIndex = {}
    for (const field of SEFAZ_REQUIRED_FIELDS) {
      const idx = findColumnIndex(headerRow, field.names)
      if (idx === -1) throw new ConciliacaoImportError(msgColunaAusente(field.label))
      colIndex[field.key] = idx
    }

    // Fornecedor = 1ª "RAZAO SOCIAL", de preferência logo após "IE EMISSOR"
    const ieEmissorIdx = findColumnIndex(headerRow, ['IE EMISSOR'])
    let fornecedorIdx = -1
    if (ieEmissorIdx !== -1 && normalizeHeader(headerRow[ieEmissorIdx + 1]) === 'RAZAO SOCIAL') {
      fornecedorIdx = ieEmissorIdx + 1
    } else {
      fornecedorIdx = findColumnIndex(headerRow, ['RAZAO SOCIAL', 'FORNECEDOR', 'NOME EMISSOR'])
    }
    if (fornecedorIdx === -1) throw new ConciliacaoImportError(msgColunaAusente('Fornecedor'))

    const chaveIdx = findColumnIndex(headerRow, ['CHAVE', 'CHAVE DE ACESSO'])

    const rows = dataRows.map((cells) => {
      const get = (idx) => (idx == null || idx === -1 ? '' : cells[idx])
      const cnpjEmissorDigits = Engine.normalizeCNPJ(get(colIndex.cnpjEmissor))
      const cnpjDestinatarioDigits = Engine.normalizeCNPJ(get(colIndex.cnpjDestinatario))
      return {
        uf: Engine.stripQuotes(get(colIndex.uf)).toUpperCase(),
        chave: Engine.stripQuotes(get(chaveIdx)),
        nf: Engine.stripQuotes(get(colIndex.nf)),
        serie: Engine.stripQuotes(get(colIndex.serie)),
        emissaoRaw: Engine.stripQuotes(get(colIndex.emissao)),
        emissao: Engine.parseDateBR(get(colIndex.emissao)),
        cnpjEmissor: cnpjEmissorDigits,
        cnpjEmissorFormatado: Engine.formatCNPJ(cnpjEmissorDigits),
        fornecedor: Engine.stripQuotes(get(fornecedorIdx)),
        cnpjDestinatario: cnpjDestinatarioDigits,
        cfop: parseInt(Engine.stripQuotes(get(colIndex.cfop)), 10) || 0,
        situacao: Engine.stripQuotes(get(colIndex.situacao)).toUpperCase(),
        tipo: Engine.stripQuotes(get(colIndex.tipo)).toUpperCase(),
        valor: Engine.normalizeValor(get(colIndex.valor)),
        rejeitada: Engine.stripQuotes(get(colIndex.rejeitada)).toUpperCase(),
      }
    })

    return { rows, rawMatrix: matrix, colIndex }
  }

  // -----------------------------------------------------------------------
  // Sistema (XLSX/XLS)
  // -----------------------------------------------------------------------

  const SISTEMA_REQUIRED_FIELDS = [
    { key: 'nf', names: ['NF', 'NUMERO NF', 'NUMERO', 'Nº NF'], label: 'NF' },
    {
      key: 'valor',
      names: ['VLR. NOTA', 'VLR NOTA', 'VALOR DA NOTA', 'VALOR NOTA', 'VLR. DA NOTA', 'VALOR'],
      label: 'Vlr. Nota',
    },
  ]

  const SISTEMA_OPTIONAL_FIELDS = [
    { key: 'fornecedor', names: ['FORNECEDOR'] },
    { key: 'dataEmissao', names: ['DATA EMISSAO', 'DATA DE EMISSAO', 'EMISSAO'] },
    { key: 'chave', names: ['CHAVE DE ACESSO', 'CHAVE NFE', 'CHAVE_NFE', 'CHAVE'] },
    // Só vem preenchido quando o sistema foi buscado pelo conector-erp (o export
    // manual do Moura nunca tem essa coluna) — habilita o botão de DANFE na tabela.
    { key: 'xml', names: ['XML NFE', 'CONTEUDO XML', 'CONTEUDO_ARQUIVO_XML', 'XML'] },
  ]

  async function parseSistemaXlsx(file) {
    let buffer
    try {
      buffer = await readFileAsArrayBuffer(file)
    } catch (e) {
      throw new ConciliacaoImportError(MSG_ARQUIVO_INVALIDO)
    }

    const bytes = new Uint8Array(buffer.slice(0, 8))
    if (!isZipSignature(bytes) && !isOleSignature(bytes)) {
      throw new ConciliacaoImportError(MSG_ARQUIVO_INVALIDO)
    }

    let workbook
    try {
      workbook = global.XLSX.read(buffer, { type: 'array' })
    } catch (e) {
      throw new ConciliacaoImportError(MSG_FORMATO_INVALIDO)
    }

    // usa a primeira planilha com conteúdo
    let matrix = []
    for (const sheetName of workbook.SheetNames) {
      const sheet = workbook.Sheets[sheetName]
      fixSheetRange(sheet)
      const candidate = global.XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: '' })
      const filtered = candidate.filter((row) => row.some((cell) => String(cell).trim() !== ''))
      if (filtered.length > 1) {
        matrix = filtered
        break
      }
    }

    const result = sistemaRowsFromMatrix(matrix)
    result.fileName = file.name
    return result
  }

  // Reconstrói as linhas do sistema a partir da matriz bruta (linha 0 =
  // cabeçalho). Detecta automaticamente a origem (Moura ou Atak) e delega
  // para o parser específico. Compartilhado entre o parser de arquivo e a
  // importação de um arquivo de conciliação (.json).
  function sistemaRowsFromMatrix(rawMatrix) {
    const matrix = (rawMatrix || []).filter(
      (row) => Array.isArray(row) && row.some((cell) => String(cell).trim() !== '')
    )
    if (matrix.length === 0) throw new ConciliacaoImportError(MSG_ARQUIVO_VAZIO)

    return detectSistemaOrigem(matrix) === 'atak'
      ? sistemaAtakRowsFromMatrix(matrix)
      : sistemaMouraRowsFromMatrix(matrix)
  }

  // Marcadores exclusivos do relatório do Atak (usado pela filial do CD).
  function detectSistemaOrigem(matrix) {
    for (const row of matrix.slice(0, 60)) {
      for (const cell of row) {
        // Só olha células "curtas" (cabeçalho/marcador) — colunas de texto livre
        // longo (ex.: o XML da NF-e, que o conector-erp inclui pra habilitar a
        // DANFE) podem conter a substring "atak.com.br" por coincidência (ex.: um
        // e-mail do próprio cliente/fornecedor Atak) sem o arquivo ser do Atak.
        if (typeof cell === 'string' && cell.length > 80) continue
        const h = normalizeHeader(cell)
        if (h === 'CHAVE FATO' || h.indexOf('TIPO MOVTO') === 0) return 'atak'
        if (typeof cell === 'string' && cell.toLowerCase().indexOf('atak.com.br') !== -1) return 'atak'
      }
    }
    const temDocumentoValorTotal = matrix.some(
      (row) =>
        row.some((c) => normalizeHeader(c) === 'DOCUMENTO') &&
        row.some((c) => normalizeHeader(c) === 'VALOR TOTAL')
    )
    return temDocumentoValorTotal ? 'atak' : 'moura'
  }

  function sistemaMouraRowsFromMatrix(matrix) {
    const headerRow = matrix[0]
    const dataRows = matrix.slice(1)
    if (dataRows.length === 0) throw new ConciliacaoImportError(MSG_ARQUIVO_VAZIO)

    const colIndex = {}
    for (const field of SISTEMA_REQUIRED_FIELDS) {
      const idx = findColumnIndex(headerRow, field.names)
      if (idx === -1) throw new ConciliacaoImportError(msgColunaAusente(field.label))
      colIndex[field.key] = idx
    }
    for (const field of SISTEMA_OPTIONAL_FIELDS) {
      colIndex[field.key] = findColumnIndex(headerRow, field.names)
    }

    const rows = dataRows.map((cells) => {
      const get = (idx) => (idx == null || idx === -1 ? '' : cells[idx])
      return {
        nf: Engine.stripQuotes(get(colIndex.nf)),
        valor: Engine.normalizeValor(get(colIndex.valor)),
        fornecedor: Engine.stripQuotes(get(colIndex.fornecedor)),
        dataEmissao: get(colIndex.dataEmissao),
        // Chave de Acesso da NF-e (44 dígitos) — quando o export do sistema traz essa
        // coluna, a casagem com a SEFAZ pode ser exata em vez de NF+valor (ver
        // Engine.buildIndices/encontraRecebida). Nem todo lançamento tem chave (ex.:
        // entradas de serviço) — nesses casos cai no fallback de sempre.
        chave: Engine.stripQuotes(get(colIndex.chave)),
        // XML completo da NF-e — só o conector-erp traz isso (ver comentário acima).
        // Sem stripQuotes: é o conteúdo bruto do XML, não um texto de planilha.
        xml: String(get(colIndex.xml) || ''),
      }
    })

    return { rows, rawMatrix: matrix, origem: 'moura' }
  }

  // Atak (filial do CD). O nº da NF e a série vêm da coluna "Documento", no
  // formato `filial-tipo-serie-numero` (ex.: 111-NEE-000-139439 -> série 000,
  // NF 139439). O valor é a coluna "Valor Total". Linhas de seção
  // ("Tipo Movto.:") e de total ("Total do Movimento:", "Total Geral:") são
  // ignoradas porque o último trecho de "Documento" não é numérico.
  // Devolve um rawMatrix já no layout do Moura (Entrada/NF/Fornecedor/.../
  // Vlr. Nota) para que o "Relatório Formatado" (Excel) funcione sem ajuste.
  const ATAK_MATRIX_HEADER = [
    'Entrada', 'NF', 'Fornecedor', 'Desconto', 'Vlr. Nota',
    'Valor Contas a Pagar', 'Pedido', 'Conferência', 'Data Emissão',
  ]

  function parseDocumentoAtak(valor) {
    const partes = String(valor == null ? '' : valor)
      .split('-')
      .map((p) => p.trim())
      .filter((p) => p !== '')
    if (partes.length < 3) return null
    const numero = partes[partes.length - 1]
    if (!/^\d+$/.test(numero)) return null
    return { nf: numero, serie: partes[partes.length - 2] }
  }

  function sistemaAtakRowsFromMatrix(matrix) {
    const headerIdx = matrix.findIndex(
      (row) =>
        row.some((c) => normalizeHeader(c) === 'DOCUMENTO') &&
        row.some((c) => ['VALOR TOTAL', 'VALOR LIQUIDO'].includes(normalizeHeader(c)))
    )
    if (headerIdx === -1) throw new ConciliacaoImportError(msgColunaAusente('Documento / Valor Total'))

    const headerRow = matrix[headerIdx]
    const docIdx = findColumnIndex(headerRow, ['DOCUMENTO'])
    const valorIdx = findColumnIndex(headerRow, ['VALOR TOTAL', 'VALOR LIQUIDO', 'VALOR'])
    const fornecedorIdx = findColumnIndex(headerRow, ['NOME DO CADASTRO', 'FORNECEDOR', 'NOME DO CLIENTE'])

    const rows = []
    for (let i = headerIdx + 1; i < matrix.length; i++) {
      const cells = matrix[i]
      const doc = parseDocumentoAtak(cells[docIdx])
      if (!doc) continue
      rows.push({
        nf: doc.nf,
        serie: doc.serie,
        valor: Engine.normalizeValor(cells[valorIdx]),
        fornecedor: limparNomeCadastroAtak(fornecedorIdx === -1 ? '' : cells[fornecedorIdx]),
        dataEmissao: '',
      })
    }
    if (rows.length === 0) throw new ConciliacaoImportError(MSG_ARQUIVO_VAZIO)

    const rawMatrix = [ATAK_MATRIX_HEADER.slice()]
    for (const r of rows) {
      rawMatrix.push(['', Number(r.nf), r.fornecedor, '', r.valor, '', '', '', ''])
    }

    return { rows, rawMatrix, origem: 'atak' }
  }

  // "90327-ARCELOMITTAL BRASIL" -> "ARCELOMITTAL BRASIL"
  function limparNomeCadastroAtak(valor) {
    return Engine.stripQuotes(valor).replace(/^\s*\d+\s*-\s*/, '').trim()
  }

  global.ConciliacaoParsers = {
    ConciliacaoImportError,
    parseSefazCsv,
    parseSistemaXlsx,
    sefazRowsFromMatrix,
    sistemaRowsFromMatrix,
    detectSistemaOrigem,
    MSG_ARQUIVO_INVALIDO,
    MSG_ARQUIVO_VAZIO,
    MSG_FORMATO_INVALIDO,
  }
})(typeof window !== 'undefined' ? window : globalThis)
