const sql = require('mssql')

// Layout de saída = exatamente o cabeçalho que o export manual do Moura já usa hoje
// (Parsers.sistemaMouraRowsFromMatrix em js/conciliacao-parsers.js). Isso permite
// reaproveitar o parser existente no front-end sem nenhuma lógica nova no cliente.
const CABECALHO_MOURA = [
  'Entrada',
  'NF',
  'Fornecedor',
  'Vlr. Produtos',
  'Vlr. Serviços',
  'ICMS',
  'IPI',
  'Desconto',
  'Vlr. Nota',
  'Valor Contas Pagar',
  'Cód Forn',
  'Observação',
  'Vlr. ICMS Subst',
  'Data Emissão',
  'Chave de Acesso',
  'Empresa',
  // Coluna extra (não existe no export manual do Moura) — só quando o sistema vem
  // do conector-erp o XML fica disponível, e só nesse caso a página mostra o botão
  // de abrir a DANFE (ver SISTEMA_OPTIONAL_FIELDS em js/conciliacao-parsers.js).
  'XML NFe',
]

// TODO: confirmar o JOIN do nome do fornecedor. Entrada_Produto (na consulta que veio
// do usuário) não traz o nome — só deve existir um Cod_Forn/Cod_Fornecedor pra cruzar
// com uma tabela de parceiros/fornecedores. Até isso ser confirmado no banco real,
// Fornecedor sai vazio.
//
// TODO: confirmar a coluna de "Vlr. Nota" (valor total da nota, usado hoje pra casar
// com a SEFAZ quando não há Chave de Acesso). A consulta original só tem
// Valor_Produtos — usamos como placeholder abaixo.
async function buscarEntradaProduto(pool, { de, ate }) {
  const request = pool.request()
  request.input('de', sql.Date, de)
  request.input('ate', sql.Date, ate)

  const result = await request.query(`
    SELECT
      Data_Cadastro,
      Data_emissao,
      Data_entrada,
      Nota_Fiscal,
      Valor_Produtos,
      chave,       -- PK pra outra tabela (não usado aqui)
      Chave_NFE,   -- chave de acesso da NF-e (44 dígitos)
      Conteudo_Arquivo_Xml
    FROM Entrada_Produto
    WHERE Data_emissao >= @de AND Data_emissao < DATEADD(day, 1, @ate)
    ORDER BY Data_emissao
  `)

  return result.recordset
}

function formatarData(value) {
  if (!value) return ''
  const d = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(d.getTime())) return ''
  const dia = String(d.getDate()).padStart(2, '0')
  const mes = String(d.getMonth() + 1).padStart(2, '0')
  return `${dia}/${mes}/${d.getFullYear()}`
}

function linhasParaRawMatrix(linhas, unidadeNome) {
  const corpo = linhas.map((row) => [
    formatarData(row.Data_entrada || row.Data_Cadastro),
    row.Nota_Fiscal != null ? String(row.Nota_Fiscal) : '',
    '', // Fornecedor — TODO: JOIN pendente
    row.Valor_Produtos != null ? row.Valor_Produtos : '',
    '',
    '',
    '',
    '',
    row.Valor_Produtos != null ? row.Valor_Produtos : '', // Vlr. Nota — TODO: placeholder (ver comentário acima)
    '',
    '',
    '',
    '',
    formatarData(row.Data_emissao),
    row.Chave_NFE || '',
    unidadeNome,
    row.Conteudo_Arquivo_Xml || '',
  ])
  return [CABECALHO_MOURA, ...corpo]
}

module.exports = { buscarEntradaProduto, linhasParaRawMatrix, CABECALHO_MOURA }
