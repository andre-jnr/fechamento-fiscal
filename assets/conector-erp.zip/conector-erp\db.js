const sql = require('mssql')
const UNIDADES = require('./config/unidades')

// Um pool de conexão por unidade, criado sob demanda e reaproveitado entre requisições.
const pools = new Map()

function getUnidade(chave) {
  return UNIDADES.find((u) => u.chave === chave)
}

async function getPool(chave) {
  const unidade = getUnidade(chave)
  if (!unidade) throw new Error(`Unidade desconhecida: ${chave}`)

  if (pools.has(chave)) {
    const existing = pools.get(chave)
    if (existing.connected) return existing
    pools.delete(chave)
  }

  const pool = new sql.ConnectionPool({
    server: unidade.server,
    database: unidade.database,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    port: Number(process.env.DB_PORT) || 1433,
    options: {
      encrypt: false, // SQL Server on-premises via VPN — sem TLS configurado
      trustServerCertificate: true,
    },
    connectionTimeout: 10000,
    requestTimeout: 30000,
  })

  await pool.connect()
  pools.set(chave, pool)
  return pool
}

module.exports = { getPool, getUnidade, UNIDADES }
